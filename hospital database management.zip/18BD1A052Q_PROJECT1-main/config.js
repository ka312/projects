module.exports = {
    secret: 'kmit micro project programme'
  };